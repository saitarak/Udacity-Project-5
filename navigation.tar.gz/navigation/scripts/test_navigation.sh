#!/bin/sh
xterm -e " roslaunch my_robot world.launch " &
sleep 5
xterm -e " roslaunch turtlebot_gazebo amcl.launch " &
sleep 5
xterm -e " roslaunch turtlebot_rviz_launchers navigation.launch " 


