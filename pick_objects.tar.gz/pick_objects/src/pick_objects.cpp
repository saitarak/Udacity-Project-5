#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;
int main(int argc, char** argv){
  ros::init(argc, argv, "simple_navigation_goals");
  MoveBaseClient ac("move_base", true);
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up for pickup");
  }
  move_base_msgs::MoveBaseGoal pickup;
  move_base_msgs::MoveBaseGoal dropoff;
  pickup.target_pose.header.frame_id = "map";
  pickup.target_pose.header.stamp = ros::Time::now();
  pickup.target_pose.pose.position.x = 1.0;
  pickup.target_pose.pose.position.y = 1.0;
  pickup.target_pose.pose.orientation.w = 1.0;
  ROS_INFO("Sending pickup goal");
  ac.sendGoal(pickup);
  ac.waitForResult();
  if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
    ROS_INFO("Hooray, robot reached pickup location");
  else
    ROS_INFO("Robot failed to move to pickup location");
  
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up for dropoff");
  }  
  dropoff.target_pose.header.frame_id = "map";
  dropoff.target_pose.header.stamp = ros::Time::now();
  dropoff.target_pose.pose.position.x = 2.0;
  dropoff.target_pose.pose.position.y = 2.0;
  dropoff.target_pose.pose.orientation.w = 2.0;
  ROS_INFO("Sending dropoff goal");
  ac.sendGoal(dropoff);
  ac.waitForResult();
  if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
    ROS_INFO("Hooray, robot reached dropoff location");
  else
    ROS_INFO("Robot failed to move to dropoff location");
  return 0;
}
